#!/usr/bin/env bash

# Stats script for golden-miner - placeholder
# Return empty if no API available