#!/usr/bin/env bash

# Ensure all scripts have execute permissions
chmod +x "$(dirname "$0")"/h-run.sh 2>/dev/null || true
chmod +x "$(dirname "$0")"/h-stats.sh 2>/dev/null || true
chmod +x "$(dirname "$0")"/golden-miner-pool-prover 2>/dev/null || true

# Load manifest to get configuration paths
[[ -f h-manifest.conf ]] && . h-manifest.conf || {
  CUSTOM_CONFIG_FILENAME="/hive/miners/custom/golden-miner.conf"
  PUBKEY="CkPLfR2Y5qBZG8vHhgTWbWxiEPvG29pgDJ4x2LrXA5fC61bRxowiw2b"
  LABEL="home"
  NAME="3070"
}

# Get user configuration or use defaults
PUBKEY="${CUSTOM_USER_CONFIG:+$(echo "$CUSTOM_USER_CONFIG" | cut -d' ' -f1)}"
PUBKEY="${PUBKEY:-CkPLfR2Y5qBZG8vHhgTWbWxiEPvG29pgDJ4x2LrXA5fC61bRxowiw2b}"
LABEL="${CUSTOM_LABEL:-home}"
NAME="${CUSTOM_NAME_PARAM:-3070}"

# Create directory and config file
[[ -n "$CUSTOM_CONFIG_FILENAME" ]] && {
  mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")" 2>/dev/null || true
  echo "--pubkey=$PUBKEY --label=$LABEL --name=$NAME" > "$CUSTOM_CONFIG_FILENAME" 2>/dev/null || true
}