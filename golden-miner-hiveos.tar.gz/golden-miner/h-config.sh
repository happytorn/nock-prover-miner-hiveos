#!/bin/bash

# Default config for golden-miner
PUBKEY="${PUBKEY:-CkPLfR2Y5qBZG8vHhgTWbWxiEPvG29pgDJ4x2LrXA5fC61bRxowiw2b}"
LABEL="${LABEL:-home}"
NAME="${NAME:-3070}"

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME

# Generating config - for this miner, the config is the command line args
echo "--pubkey=$PUBKEY --label=$LABEL --name=$NAME" > $CUSTOM_CONFIG_FILENAME