#!/bin/bash

[[ `ps aux | grep "golden-miner-pool-prover" | grep -v grep | wc -l` != 0 ]] &&
  echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" &&
  exit 1

. h-manifest.conf

unset LD_LIBRARY_PATH

conf=`cat $MINER_CONFIG_FILENAME`

eval "unbuffer ./golden-miner-pool-prover $conf"