#!/bin/bash

./golden-miner-pool-prover --pubkey=$PUBKEY --label=$LABEL --name=$NAME