#!/usr/bin/env bash

# Create directory and config file
mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"

# Get user configuration or use defaults
PUBKEY="${CUSTOM_USER_CONFIG:-CkPLfR2Y5qBZG8vHhgTWbWxiEPvG29pgDJ4x2LrXA5fC61bRxowiw2b}"
LABEL="${CUSTOM_LABEL:-home}"
NAME="${CUSTOM_NAME_PARAM:-3070}"

# Generate config file
echo "--pubkey=$PUBKEY --label=$LABEL --name=$NAME" > "$CUSTOM_CONFIG_FILENAME"