#!/usr/bin/env bash

# Load manifest to get configuration paths
[[ -f h-manifest.conf ]] && . h-manifest.conf

# Get user configuration or use defaults
PUBKEY="${CUSTOM_USER_CONFIG:-CkPLfR2Y5qBZG8vHhgTWbWxiEPvG29pgDJ4x2LrXA5fC61bRxowiw2b}"
LABEL="${CUSTOM_LABEL:-home}"
NAME="${CUSTOM_NAME_PARAM:-3070}"

# Create directory and config file if CUSTOM_CONFIG_FILENAME is defined
if [[ -n "$CUSTOM_CONFIG_FILENAME" ]]; then
  mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"
  echo "--pubkey=$PUBKEY --label=$LABEL --name=$NAME" > "$CUSTOM_CONFIG_FILENAME"
fi

# HiveOS required function
miner_config_gen()
{
  # Generate config file
  if [[ -n "$CUSTOM_CONFIG_FILENAME" ]]; then
    mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"
    echo "--pubkey=$PUBKEY --label=$LABEL --name=$NAME" > "$CUSTOM_CONFIG_FILENAME"
  fi
}

# HiveOS required function
miner_ver()
{
  # Return version
  [[ -n "$CUSTOM_VERSION" ]] && echo "$CUSTOM_VERSION" || echo "hiveos"
}