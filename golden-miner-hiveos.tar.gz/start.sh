#!/bin/bash
./golden-miner-pool-prover --pubkey=CkPLfR2Y5qBZG8vHhgTWbWxiEPvG29pgDJ4x2LrXA5fC61bRxowiw2b --label=home --name=3070