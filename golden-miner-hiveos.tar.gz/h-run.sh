#!/bin/bash

. h-manifest.conf

[[ `ps aux | grep "golden-miner-pool-prover" | grep -v grep | wc -l` != 0 ]] &&
  echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" &&
  exit 1

unset LD_LIBRARY_PATH

if [[ -f "$MINER_CONFIG_FILENAME" ]]; then
  conf=`cat "$MINER_CONFIG_FILENAME"`
else
  conf="--pubkey=CkPLfR2Y5qBZG8vHhgTWbWxiEPvG29pgDJ4x2LrXA5fC61bRxowiw2b --label=home --name=3070"
fi

cd "$(dirname "$0")"
./golden-miner-pool-prover $conf